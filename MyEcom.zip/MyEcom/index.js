const app=require('./app');

app.listen(5030,function (){
    console.log("App Run at Port no:5030");
})