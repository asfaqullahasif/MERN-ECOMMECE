const BrandModel=require('../Models/BrandModel');
const CategoryModel= require("../Models/CategoryModel");
const ProductModel=require("../Models/ProductModel");
const ProductDetailModel=require('../Models/ProductDetailModel');
const ProductSliderModel=require('../Models/ProductSliderModel');
const ReviewModel=require('../Models/ReviewModel');
const mongoose=require('mongoose');

const ObjectID = mongoose.Types.ObjectId;




const BrandListServices=async ()=>{

    try{
        let data=await BrandModel.find();
        return{status:"success", data:data};
    }
    catch (e){
        return {status:"fail", data:e}.toString();
    }
}
const CategoryListServices=async ()=>{
    try{
        let data = await CategoryModel.find();
        return{status:'success', data:data}
    }
    catch (e){
        return {status:'fail', data:e}.toString();
    }
}
const SliderListServices=async ()=>{
    try{
        let data=await ProductSliderModel.find();
        return{status:"success", data:data};
    }
    catch(e){
        return {status:'fail', data:e}.toString();
    }
}






const ListByBrandServices=async (req)=>{
    try{
        let BrandID =new ObjectID(req.params.BrandID);

        let MatchStage= {$match:{brandID:BrandID}};
        let JoinWithBrandStage = {$lookup:{from:"brands",localField:"brandID",foreignField:"_id", as:"brand"}};
        let JoinWithCategoryStage = {$lookup: {from:"categories", localField: "categoryID",foreignField: "_id",as:"category"}};
        let UnwindBrandStage = {$unwind:"$brand"};
        let UnwindCategoryStage={$unwind: '$category'};

        let ProjectionStage={$project:{'brand._id':0,'category._id':0, 'categoryID':0,'brandID':0}};

        let data= await ProductModel.aggregate([
            MatchStage, JoinWithBrandStage, JoinWithCategoryStage,
            UnwindBrandStage,UnwindCategoryStage, ProjectionStage
        ])
        return{status:'success', data:data};
    }
    catch (e){
        return {status:'fail', data:e}.toString();
    }
}

const ListByCategoryServices=async (req)=>{
    try {
        let CategoryID=new ObjectID(req.params.CategoryID);
        let MatchStage={$match: {categoryID:CategoryID}};
        let JoinWithBrandStage={$lookup:{from:'brands',localField:'brandID',foreignField:'_id',as:'brand'}};
        let JoinWithCategoryStage = {$lookup:{from:'categories', localField:'categoryID', foreignField:'_id', as:'category'}};
        let UnwindWithBrand = {$unwind:'$brand'};
        let UnwindWithCategory={$unwind:'$category'};

        let ProjectionState={$project: {'brand._id':0, 'category._id':0, 'brandID':0, 'categoryID':0}};

        let data = await ProductModel.aggregate([
            MatchStage,
            JoinWithBrandStage,JoinWithCategoryStage,
            UnwindWithBrand,UnwindWithCategory,
            ProjectionState
        ])
        return {status:'success', data:data};

    }
    catch (e){
        return{status:'fail', data:e}.toString();
    }
}

const ListByRemarksServices=async (req)=>{
    try{
        let Remark= req.params.Remark;
        let MatchStage = {$match:{remark:Remark}};
        let JoinWithBrandStage={$lookup:{from:'brands', localField:'brandID', foreignField:'_id',as:'brand'}};
        let JoinWithCategoryStage={$lookup:{from:'categories',localField:'categoryID', foreignField:'_id',as:'category'}};
        let UnwindWithBrand={$unwind:'$brand'};
        let UnwindWithCategory={$unwind:"$category"};

        let ProjectionStage={$project:{'brand._id':0,'category._id':0,'categoryID':0,'brandID':0}};


        let data= await ProductModel.aggregate([
            MatchStage,
            JoinWithBrandStage,JoinWithCategoryStage,
            UnwindWithBrand,UnwindWithCategory,
            ProjectionStage
        ])
        return {status:'success', data:data};
    }
    catch (e){
        return{status:'fail', data:e}.toString();
    }
}








const ListBySmilierServices=async (req)=>{
    try{
        let CategoryID= new ObjectID(req.params.CategoryID);

        let limitStage = {$limit:10};

        let MatchingStage={$match:{categoryID:CategoryID}};

        let JoinWithBrandStage={$lookup:{from:'brands', localField:'brandID', foreignField:'_id',as:'brand'}};
        let JoinWithCategoryStage={$lookup:{from:'categories', localField:'categoryID',foreignField:'_id', as:'category'}};

        let UnwindWithBrand ={$unwind:'$brand'};
        let UnwindWithCategory = {$unwind:'$category'};

        let ProjectionStage={$project:{'brand._id':0, 'category._id':0, 'brandID':0, 'categoryID':0}};

        let data= await ProductModel.aggregate([
            MatchingStage,limitStage,
            JoinWithBrandStage,JoinWithCategoryStage,
            UnwindWithBrand,UnwindWithCategory,
            ProjectionStage
        ])
        return{status:'success', data:data};
    }
    catch (e){
        return {status:'fail', data:e}.toString();
    }
}
const ListByKeywordServices=async (req)=>{
    try{
        let SearchRegex= {'$regex':req.params.Keyword,'$options':'i'};

        //{'options':'i'}  makes search keyword case-insensitive

        let SearchParams=[{title:SearchRegex},{shortDes:SearchRegex}];
        let SearchQuery={$or:SearchParams};
        let MatchingStage = {$match:SearchQuery};

        let JoinWithBrand={$lookup:{from:'brands', localField:'brandID', foreignField:'_id', as:'brand'}};
        let JoinWithCategory = {$lookup:{from:'categories', localField:'categoryID',foreignField:'_id', as:'category'}}
        let UnwindWithBrand={$unwind:'$brand'};
        let UnwindWithCategory={$unwind:'$category'};
        let ProjectionStage={$project:{'brand._id':0, 'category._id':0, 'brandID':0,'categoryID':0}}

        let data=await ProductModel.aggregate([
            MatchingStage,
            JoinWithBrand,JoinWithCategory,
            UnwindWithCategory,UnwindWithBrand,
            ProjectionStage
        ])
        return{status:'success', data:data};

    }catch (e) {
        return {status:'fail', data:e}.toString();
    }
}
const ProductDetailServices=async (req)=>{

    try{
        let ProductID= new ObjectID(req.params.ProductID);

        let MatchStage={$match:{_id:ProductID}};

        let JoinWithBrandStage = {$lookup:{from:'brands', localField:'brandID', foreignField:'_id', as:'brand'}};
        let JoinWithCategoryStage={$lookup:{from:'categories', localField:'categoryID', foreignField:'_id', as:'category'}};
        let JoinWithProductDetailStage={$lookup:{from:'productDetails', localField:'_id', foreignField:'productID', as:'productDetails'}};

        let UnwindWithBrand={$unwind:'$brand'};
        let UnwindWithCategory={$unwind:'$category'};
        let UnwindWithProductDetails={$unwind:'$productDetails'};

        let ProjectionStage={$project:{'brand._id':0,'category._id':0,'brandID':0, 'categoryID':0}};

        let data = await ProductModel.aggregate([
            MatchStage,
            JoinWithBrandStage,JoinWithCategoryStage,JoinWithProductDetailStage,
            UnwindWithBrand,UnwindWithCategory,UnwindWithProductDetails,
            ProjectionStage
        ])

        return {status:'success', data:data};
    }
    catch(e){
        return{status:'fail', data:e}.toString();
    }

}


const ReviewListServices=async (req)=>{
    try{
        let ProductID= new ObjectID(req.params.ProductID);
        let MatchingStage = {$match:{productID:ProductID}};

        let JoinWithProfileStage={$lookup:{from:'profiles',localField:'userID', foreignField:'userID', as:'profile'}};
        let UnwindProfileStage={$unwind:'$profile'};
        let ProjectionStage={
            $project:{
                'des':1,
                'rating':1,
                'profile.cus_name':1
            }
        }


        let data = await ReviewModel.aggregate([
            MatchingStage,
            JoinWithProfileStage,
            UnwindProfileStage,
            ProjectionStage
        ])
        return{status:'success', data:data};
    }catch(e){
        return{status:'fail', data:e}.toString();
    }
}







module.exports={ BrandListServices,CategoryListServices,SliderListServices,
    ListByBrandServices,ListByCategoryServices,ListBySmilierServices,ListByKeywordServices,
    ReviewListServices,ListByRemarksServices,ProductDetailServices
}